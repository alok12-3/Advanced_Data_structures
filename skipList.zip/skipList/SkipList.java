import java.util.ArrayList;
import java.util.Collections;

public class SkipList {

    public SkipListNode head;
    public SkipListNode tail;
    public int height;
    public Randomizer randomizer;
    private final int NEG_INF = Integer.MIN_VALUE;
    private final int POS_INF = Integer.MAX_VALUE;

    SkipList() {
        /*
         * DO NOT EDIT THIS FUNCTION
         */
        this.head = new SkipListNode(NEG_INF, 1);
        this.tail = new SkipListNode(POS_INF, 1);
        this.head.next.add(0, this.tail);
        this.tail.next.add(0, null);
        this.height = 1;
        this.randomizer = new Randomizer();
    }

    private void deleteHelper(SkipListNode current, ArrayList<SkipListNode> storage) {
        for (int i = 0; i < this.height; i++) {
            if (storage.get(i).next.get(i) == current) {
                storage.get(i).next.set(i, current.next.get(i));
            }
        }
        while (this.head.next.get(this.height - 1) == this.tail && this.height > 1) {
            this.head.height--;
            this.tail.height--;
            this.height--;
            this.head.next.remove(this.height);
            this.tail.next.remove(this.height);
        }
    }

    public boolean delete(int num) {
        SkipListNode current = this.head;
        // no need to make a separate copy for the storage
        ArrayList<SkipListNode> storage = new ArrayList<>(Collections.nCopies(this.height, null));
        for (int i = this.height - 1; i >= 0; i--) {
            while (current.next.get(i).value < num) {
                current = current.next.get(i);
            }
            storage.set(i, current);
        }
        // bring to the ground floor.
        current = current.next.get(0);
        // if the number is found
        if (current.value == num) {
            deleteHelper(current, storage);
            return true;
        }
        return false;
    }

    public boolean search(int num) {

        SkipListNode current = this.head;
        for (int i = this.height - 1; i >= 0; i--) {
            while (current.next.get(i).value <= num) {
                if (current.next.get(i).value == num) {
                    return true;
                }
                current = current.next.get(i);
            }
        }
        return false;

    }

    public Integer upperBound(int num) {
        SkipListNode current = this.head;
        for (int i = this.height - 1; i >= 0; i--) {
            while (current.next.get(i).value <= num) {
                current = current.next.get(i);

            }
            if (i == 0) {
                return current.next.get(i).value;
            }
        }
        return Integer.MIN_VALUE;
    }

    public void insert(int num) {
        SkipListNode current = this.head;
        ArrayList<SkipListNode> storage = new ArrayList<>(Collections.nCopies(this.height, null));
        for (int i = this.height - 1; i >= 0; i--) {
            while (current.next.get(i).value < num) {
                // System.out.println(current.next.size() + "");
                current = current.next.get(i);
            }
            storage.set(i, current);
        }

        // node height calculation
        int nodeHeight = 1;
        while (randomizer.binaryRandomGen()) {
            nodeHeight++;
            if (nodeHeight == this.height + 1)
                break;
        }

        if (this.height < nodeHeight) {
            this.height++;
            this.head.height++;
            this.tail.height++;
            this.head.next.add(this.height - 1, this.tail);
            this.tail.next.add(this.height - 1, null);

            // changing the height by making a temp
            ArrayList<SkipListNode> storage_new = new ArrayList<>(Collections.nCopies(this.height, this.head));
            for (int i = 0; i < storage.size(); i++) {
                storage_new.set(i, storage.get(i));
            }
            storage = storage_new;

        }

        // connect the pointers
        SkipListNode newNode = new SkipListNode(num, nodeHeight);
        for (int i = 0; i < nodeHeight; i++) {
            newNode.next.add(i, storage.get(i).next.get(i));
            storage.get(i).next.set(i, newNode);
        }
    }

    public void print() {

        for (int i = this.height; i >= 1; --i) {
            SkipListNode it = this.head;
            while (it != null) {
                if (it.height >= i) {
                    System.out.print(it.value + "\t");
                } else {
                    System.out.print("\t");
                }
                it = it.next.get(0);
            }
            System.out.println("null");
        }
    }

}