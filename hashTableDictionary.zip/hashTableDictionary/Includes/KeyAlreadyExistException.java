package Includes;

public class KeyAlreadyExistException extends Exception{
    public KeyAlreadyExistException() {  
        System.out.println("KeyAlreadyExist"); 
    }  
}  