import java.util.LinkedList;

import Includes.DictionaryEntry;
import Includes.HashTableEntry;
import Includes.KeyAlreadyExistException;
import Includes.KeyNotFoundException;
import Includes.NullKeyException;

import java.lang.reflect.Array;

public class COL106Dictionary<K, V> {

    private LinkedList<DictionaryEntry<K, V>> dict;
    public LinkedList<HashTableEntry<K, V>>[] hashTable;
    public int size;

    @SuppressWarnings("unchecked")
    COL106Dictionary(int hashTableSize) {
        dict = new LinkedList<DictionaryEntry<K, V>>();
        hashTable = (LinkedList<HashTableEntry<K, V>>[]) Array.newInstance(LinkedList.class, hashTableSize);
        size = 0;
    }

    public void insert(K key, V value) throws KeyAlreadyExistException, NullKeyException {
        if (key == null) {
            throw new NullKeyException();
        }

        int index = hash(key);
        if (hashTable[index] == null) {
            LinkedList<HashTableEntry<K, V>> list = new LinkedList<HashTableEntry<K, V>>();
            DictionaryEntry<K, V> Dict_newEntry = new DictionaryEntry<K, V>(key, value);
            HashTableEntry<K, V> hashEntry = new HashTableEntry<K, V>(key, Dict_newEntry);
            list.add(hashEntry);
            dict.add(Dict_newEntry);
            hashTable[index] = list;
            size++;

        } else {

            for (HashTableEntry<K, V> hashEntry : hashTable[index]) {
                if (hashEntry.key.equals(key)) {
                    throw new KeyAlreadyExistException();
                }
            }
            DictionaryEntry<K, V> Dict_newEntry = new DictionaryEntry<K, V>(key, value);
            HashTableEntry<K, V> hashEntry = new HashTableEntry<K, V>(key, Dict_newEntry);
            hashTable[index].add(hashEntry);
            dict.add(Dict_newEntry);
            size++;
        }
    }

    public V delete(K key) throws NullKeyException, KeyNotFoundException {
        if (key == null)
            throw new NullKeyException();
        int index = hash(key);
        V deleted;
        if (hashTable[index] == null) {
            throw new KeyNotFoundException();
        }
        for (int i = 0; i < hashTable[index].size(); i++) {
            for (HashTableEntry<K, V> hashEntry : hashTable[index]) {
                if (hashEntry.key.equals(key)) {
                    deleted = hashEntry.dictEntry.value;
                    dict.remove(hashEntry.dictEntry);
                    hashTable[index].remove(hashEntry);
                    size--;

                    if (hashTable[index].size() == 0) {
                        hashTable[index] = null;
                    }
                    return deleted;
                }
            }

        }
        throw new KeyNotFoundException();
    }

    public V update(K key, V value) throws NullKeyException, KeyNotFoundException {
        if (key == null)
            throw new NullKeyException();

        int index = hash(key);
        if (hashTable[index] == null) {
            throw new KeyNotFoundException();
        }
        V store;
        for (HashTableEntry<K, V> hashEntry : hashTable[index]) {
            if (hashEntry.key.equals(key)) {
                store = hashEntry.dictEntry.value;
                hashEntry.dictEntry.value = value;
                return store;
            }
        }
        throw new KeyNotFoundException();
    }

    public V get(K key) throws NullKeyException, KeyNotFoundException {
        if (key == null)
            throw new NullKeyException();
        int index = hash(key);

        if (hashTable[index] == null)
            throw new KeyNotFoundException();
        V store;
        for (HashTableEntry<K, V> hashEntry : hashTable[index]) {
            if (hashEntry.key.equals(key)) {
                store = hashEntry.dictEntry.value;
                return store;
            }
        }
        throw new KeyNotFoundException();

    }

    public Boolean exist(K key) throws NullKeyException {
        if (key == null) {
            throw new NullKeyException();
        }
        int index = hash(key);

        if (hashTable[index] == null)
            return false;

        for (HashTableEntry<K, V> hashEntry : hashTable[index]) {
            if (hashEntry.key.equals(key)) {
                return true;
            }
        }
        return false;
    }

    public int size() {
        return size;
    }

    @SuppressWarnings("unchecked")
    public K[] keys(Class<K> cls) {
        K[] array = (K[]) Array.newInstance(cls, dict.size());
        for (int i = 0; i < dict.size(); i++) {
            array[i] = dict.get(i).key;
        }
        return (K[]) array;

    }

    @SuppressWarnings("unchecked")
    public V[] values(Class<V> cls) {
        V[] array = (V[]) Array.newInstance(cls, dict.size());
        for (int i = 0; i < dict.size(); i++) {
            array[i] = dict.get(i).value;
        }
        return (V[]) array;
    }

    public int hash(K key) {
        int p = 131;
        int hash = 0;
        String S = (String) key;
        long exp = 1;
        for (int i = 0; i < S.length(); i++) {
            hash = (int) ((hash + (S.charAt(i) + 1) * exp) % hashTable.length);
            exp = (exp * p) % hashTable.length;
        }
        return hash;
    }
}
