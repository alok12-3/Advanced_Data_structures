public class BalancedBST extends BST {

    // TO be completed by students
    private BSTNode calcMin(BSTNode node) {
        while (node.left != null) {
            node = node.left;
        }
        return node;
    }

    private int nodeHeight(BSTNode node) {
        int hl = (node != null && node.left != null) ? node.left.height : 0;
        int hr = (node != null && node.right != null) ? node.right.height : 0;
        return hl > hr ? hl + 1 : hr + 1;
    }

    private BSTNode rotatations(BSTNode node, int key) {
        int balance = getBalance(node);
        int balance_right = getBalance(node.right);
        int balance_left = getBalance(node.left);

        if (balance == 2 && balance_left == 1) {
            return rightRotate(node);
        }

        if (balance == -2 && balance_right == -1) {
            return leftRotate(node);
        }

        if (balance == 2 && balance_left == 1) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }

        if (balance == -2 && balance_right == -1) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }
        return node;
    }

    private int getBalance(BSTNode node) {
        if (node == null) {
            return 0;
        }
        return nodeHeight(node.left) - nodeHeight(node.right);
    }

    private BSTNode leftRotate(BSTNode node) {
        BSTNode newRoot = node.right;
        BSTNode temp = newRoot.left;
        newRoot.left = node;
        node.right = temp;
        node.height = nodeHeight(node);
        newRoot.height = nodeHeight(newRoot);
        return newRoot;
    }

    private BSTNode rightRotate(BSTNode node) {
        BSTNode newRoot = node.left;
        BSTNode temp = newRoot.right;
        newRoot.right = node;
        node.left = temp;
        node.height = nodeHeight(node);
        newRoot.height = nodeHeight(newRoot);
        return newRoot;
    }

    public void insert(int key) {
        this.root = performInsert(this.root, key);
    }

    private BSTNode performInsert(BSTNode node, int key) {
        if (node == null) {
            return new BSTNode(key);
        }

        if (key < node.value) {
            node.left = performInsert(node.left, key);
        } else {
            if (key > node.value) {
                node.right = performInsert(node.right, key);
            } else {
                return node;
            }
        }
        node.height = nodeHeight(node);
        return rotatations(node, key);
    }

    public boolean delete(int key) {
        // System.out.println("delete" + key);
        if (root == null) {
            return false;
        }
        root = performDelete(root, key);
        return true;
    }

    private BSTNode performDelete(BSTNode node, int key) {
        if (node == null) {
            return null;
        }

        if (key < node.value) {
            node.left = performDelete(node.left, key);
        } else {
            if (key > node.value) {
                node.right = performDelete(node.right, key);
            } else {
                if (node.left == null && node.right == null) {
                    return null;
                } else {
                    if (node.left == null) {
                        return node.right;
                    } else {
                        if (node.right == null) {
                            return node.left;
                        } else {
                            BSTNode minRightNode = calcMin(node.right);
                            node.value = minRightNode.value;
                            node.right = performDelete(node.right, minRightNode.value);
                        }
                    }
                }
            }

        }
        // update height of this node
        node.height = nodeHeight(node);
        // check balance factor and rotate if necessary
        return rotatations(node, key);
    }

}
