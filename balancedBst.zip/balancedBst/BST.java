import java.util.*;

public class BST {

    public BSTNode root;

    public BST() {
        root = null;
    }

    public boolean delete(int num) {
        if (root == null || search(num) == false) {
            return false;
        }

        BSTNode parent = null;
        BSTNode current = root;
        Boolean leftChildpresent = false;
        while (current != null) {
            if (current.value == num) {
                // case 1. if the current node is a leaf node
                if (current.right == null && current.left == null) {
                    if (current == root) {
                        root = null;
                    } else {
                        if (parent.value > current.value) {
                            parent.left = null;
                        } else {
                            parent.right = null;
                        }
                    }
                    return true;
                }

                // other than leaf node
                else {
                    // case 2. if the current has one child
                    // check the current is in right subtree or left subtree

                    if (current == root && root.left == null) {
                        root = current.right;
                        return true;
                    }
                    if (current == root && root.right == null) {
                        root = current.left;
                        return true;
                    }

                    if (current.left == null && current.value < parent.value) {
                        parent.left = current.right;
                        return true;
                    }
                    if (current.right == null && current.value < parent.value) {
                        parent.left = current.left;
                        return true;
                    }
                    if (current.right == null && current.value > parent.value) {
                        parent.right = current.left;
                        return true;
                    }
                    if (current.left == null && current.value > parent.value) {
                        parent.right = current.right;
                        return true;
                    }
                    // case 3 where it has 2 children
                    else {
                        // System.out.println("dele case3" + num);
                        BSTNode predp = current;
                        BSTNode initial = current.left;
                        while (initial.right != null) {
                            predp = initial;
                            initial = initial.right;
                        }
                        if (initial != current.left) {
                            predp.right = initial.left;
                            initial.left = current.left;
                        }
                        initial.right = current.right;

                        if (current == root) {
                            root = initial;
                        } else {
                            if (parent.left == current) {
                                parent.left = initial;
                            } else {
                                parent.right = initial;
                            }
                        }
                        return true;
                    }
                }
            }
            if (current.value < num) {
                parent = current;
                current = current.right;
                leftChildpresent = false;

            } else {
                parent = current;
                current = current.left;
                leftChildpresent = true;
            }

        }
        return false;
    }

    public void insert(int num) {
        // System.out.println("INSERT " + num);
        BSTNode newNode = new BSTNode(num);

        if (root == null) {
            root = newNode;
            return;
        }

        BSTNode current = root;

        while (current != null) {
            if (num < current.value) {
                if (current.left == null) {
                    current.left = newNode;
                    return;
                } else {
                    current = current.left;
                }

            } else {
                if (num > current.value) {
                    if (current.right == null) {
                        current.right = newNode;
                        return;
                    } else {
                        current = current.right;
                    }

                } else {
                    return;
                }
            }

        }
    }

    public boolean search(int num) {
        if (root == null)
            return false;
        BSTNode current = root;
        while (current != null) {
            if (num == current.value) {
                return true;
            } else {
                if (num < current.value) {
                    current = current.left;
                } else {
                    current = current.right;
                }
            }
        }
        return false;
    }

    public void preorder(BSTNode node, ArrayList<Integer> ret) {
        if (node == null) {
            return;
        }
        ret.add(ret.size(), node.value);
        preorder(node.left, ret);
        preorder(node.right, ret);
    }

    public ArrayList<Integer> preorder() {
        // TO be completed by students
        BSTNode central = root;
        ArrayList<Integer> ret = new ArrayList<>();
        preorder(central, ret);
        return ret;
    }

    public void postorder(BSTNode node, ArrayList<Integer> ret) {
        if (node == null) {
            return;
        }
        postorder(node.left, ret);
        postorder(node.right, ret);
        ret.add(ret.size(), node.value);
    }

    public ArrayList<Integer> postorder() {
        // TO be completed by students
        BSTNode central = root;
        ArrayList<Integer> ret = new ArrayList<>();
        postorder(central, ret);
        return ret;
    }

    public void inorder(BSTNode node, ArrayList<Integer> ret) {
        if (node == null) {
            return;
        }
        inorder(node.left, ret);
        ret.add(ret.size(), node.value);
        inorder(node.right, ret);
    }

    public ArrayList<Integer> inorder() {
        BSTNode target = root;
        ArrayList<Integer> ret = new ArrayList<>();
        inorder(target, ret);
        return ret;
    }

}